FS <- .Platform$file.sep
EPSILON <- 0.000001
